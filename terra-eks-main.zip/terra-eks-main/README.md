### Run the below commands

* 1. Need terraform installed in your machine then run bellow commands

```
terraform init
terraform validate
terraform plan 
terraform apply --auto-approve
terraform show
```
